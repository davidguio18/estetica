import { CreateAuditLogData } from '../../domain/audit-log.entity';

export const AUDIT_LOGGER = Symbol('AUDIT_LOGGER');

export interface AuditLogger {
  record(input: CreateAuditLogData): Promise<void>;
}
